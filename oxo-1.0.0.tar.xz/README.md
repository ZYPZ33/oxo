# oxo
Naughts and crosses game in python - for A Level computer science

to run:<br/>
    <pre style="background-color: lightgrey"><tt>git clone https://github.com/zypz33/oxo<br/>
    python oxo</pre></tt>
