install oxo /usr/local/bin/
